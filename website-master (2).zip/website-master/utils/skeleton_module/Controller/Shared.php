<?php
namespace [MODULE_NAME]\Controller;

use PPI\Module\Controller as BaseController;

class Shared extends BaseController
{

    
}