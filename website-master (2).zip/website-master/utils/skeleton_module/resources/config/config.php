<?php
$config = array();

$config['someKey'] = 'someVal';

return $config;