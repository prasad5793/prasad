<?php $view->extend('::base.html.php');?>

<div class="box">
    <div class="box-header well">Welcome to your new module: [MODULE_NAME]</div>
    <div class="box-content">
        <p>Don't forget to check out some relevant documentation you can do with your module</p>
        <ul class="unstyled">
            <li><a href="http://www.ppi.io/docs/modules.html" title="" target="_blank">Modules</a></li>
            <li><a href="http://www.ppi.io/docs/controllers.html" title="" target="_blank">Controllers</a></li>
            <li><a href="http://www.ppi.io/docs/templating.html" title="" target="_blank">Templating</a></li>
        </ul>
    </div>
</div>