<?php
return array(
	'activeModules'   => array('Framework', 'Application', 'UserModule', 'BlogModule'),
	'listenerOptions' => array('module_paths' => array('./modules'), 'routingEnabled' => true),
);