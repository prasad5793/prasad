<?php

namespace UserModule\Storage;

use PPI\DataSource\ActiveQuery;

class Base extends ActiveQuery {}
