<?php

namespace UserModule\Entity;

use UserModule\Entity\User as BaseUser;

class AuthUser extends BaseUser {}
