

<table width="600" border="0" align="center" cellpadding="0" cellspacing="0">
	<tr>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td>Hi <?=$toUser->getFullName();?>,</td>
	</tr>
	<tr>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td>
			Thank you for registering at PPI Application.<br>
			<br>
			Please use the following link to activate and complete your registration:<br>
			<?=$activationLink;?>
		</td>
	</tr>
	<tr>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td>
			Kind Regards,<br>
			PPI Team
		</td>
	</tr>
</table>
