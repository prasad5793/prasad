<?php

namespace BlogModule\Storage;

use PPI\DataSource\ActiveQuery;

class Base extends ActiveQuery {}
