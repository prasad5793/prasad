<?php

namespace Application\Storage;

use PPI\DataSource\ActiveQuery;

class Base extends ActiveQuery {}
