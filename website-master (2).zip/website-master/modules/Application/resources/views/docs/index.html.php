<?php $view->extend('::docsbase.html.php'); ?>
<?=$view->render('Application:' . $docsFolder . ':' . $page . '.html.php');?>
