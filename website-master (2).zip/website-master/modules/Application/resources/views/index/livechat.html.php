<?php $view->extend('::base.html.php'); ?>

<br>
<center>
	<iframe src="http://webchat.freenode.net/?channels=ppi" frameborder="0" style="width: 900px; height: 400px;"></iframe>
</center>